from tkinter import *
window = Tk()
window.geometry("600x400")
e = Entry(window, width=60, borderwidth=7)
e.place(x=0, y=0)

def click(num):
    result = e.get()
    e.delete(0, END)
    e.insert(0, str(result) + str(num))

def add():
    n1 = e.get()
    global i 
    global math
    math = 'Addition'
    e.delete(0, END)

def sub():
    n1 = e.get()
    global i 
    global math
    math = 'Subtraction'
    e.delete(0, END)

def mul():
    n1 = e.get()
    global i
    global math
    math = 'Multiplication'
    e.delete(0, END)

def div():
    n1 = e.get()
    global i 
    global math
    math = 'Division'
    i = int (n1)
    e.delete(0, END)
def add():
    global i
    global math
    n1 = e.get()
    i = int(n1)
    math = 'Addition'
    e.delete(0, END)

def sub():
    global i
    global math
    n1 = e.get()
    i = int(n1)
    math = 'Subtraction'
    e.delete(0, END)

def mul():
    global i
    global math
    n1 = e.get()
    i = int(n1)
    math = 'Multiplication'
    e.delete(0, END)

def div():
    global i
    global math
    n1 = e.get()
    i = int(n1)
    math = 'Division'
    e.delete(0, END)

def equal():
    n2 = e.get()
    e.delete(0, END)
    if math == 'Addition':
        e.insert(0, i + int(n2))
    elif math == 'Subtraction':
        e.insert(0, i - int(n2))
    elif math == 'Multiplication':
        e.insert(0, i * int(n2))
    elif math == 'Division':
        if int(n2) != 0:
            e.insert(0, i / int(n2))
        else:
            e.insert(0, "Error")

def clear():
    e.delete(0, END)


b1 = Button(window, text='1', width=14, command=lambda: click(1))
b1.place(x=10, y=60)
b2 = Button(window, text='2', width=14, command=lambda: click(2))
b2.place(x=80, y=60)
b3 = Button(window, text='3', width=14, command=lambda: click(3))
b3.place(x=170, y=60)
b4 = Button(window, text='4', width=14, command=lambda: click(4))
b4.place(x=10, y=120)
b5 = Button(window, text='5', width=14, command=lambda: click(5))
b5.place(x=80, y=120)
b6 = Button(window, text='6', width=14, command=lambda: click(6))
b6.place(x=170, y=120)
b7 = Button(window, text='7', width=14, command=lambda: click(7))
b7.place(x=10, y=180)
b8 = Button(window, text='8', width=14, command=lambda: click(8))
b8.place(x=80, y=180)
b9 = Button(window, text='9', width=14, command=lambda: click(9))
b9.place(x=170, y=180)
b0 = Button(window, text='0', width=14, command=lambda: click(0))
b0.place(x=10, y=240)

b_add = Button(window, text='+', width=14, command=add, bg='Green')
b_add.place(x=80, y=240)
b_sub = Button(window, text='-', width=14, command=sub, bg='Red')
b_sub.place(x=170, y=240)
b_mul = Button(window, text='*', width=14, command=mul, bg='yellow')
b_mul.place(x=110, y=300)
b_div = Button(window, text='/', width=14, command=div, bg='blue')
b_div.place(x=80, y=300)
b_eq = Button(window, text='=', width=14, command=equal , bg='cyan')
b_eq.place(x=170, y=300)
b_clear = Button(window, text='C', width=14, command=clear , bg='orange')
b_clear.place(x=170, y=350)

mainloop()